BK MOTORS WEBSITE

Files:
- index.html
- images/bike1.jpg
- images/bike2.jpg
- images/bike3.jpg

GitHub:
1. Open your repository.
2. Open index.html and choose Edit.
3. Replace the old code with this index.html code, OR upload this whole folder's files.
4. Make sure the images folder is uploaded with the three JPG files.
5. Commit changes.
6. Wait a few minutes for GitHub Pages to deploy.

IMPORTANT:
- The bike prices are intentionally "Price on enquiry" because exact prices were not provided.
- Bike model/year/km details should be corrected before publishing.
- The map currently points to Dehradun, not the exact shop.
- Change the phone number in the HTML if needed.
